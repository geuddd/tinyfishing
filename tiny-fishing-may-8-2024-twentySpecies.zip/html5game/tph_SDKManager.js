//function _0x2046(_0x478ff9,_0x518cd3){var _0x142112=_0x1421();return _0x2046=function(_0x204645,_0x383680){_0x204645=_0x204645-0x90;var _0xf22b0a=_0x142112[_0x204645];return _0xf22b0a;},_0x2046(_0x478ff9,_0x518cd3);}var _0x42b685=_0x2046;(function(_0x17295c,_0x31137a){var _0x3596ec=_0x2046,_0x2c4dbd=_0x17295c();while(!![]){try{var _0x1307b3=-parseInt(_0x3596ec(0xb9))/0x1*(-parseInt(_0x3596ec(0xd4))/0x2)+-parseInt(_0x3596ec(0xc9))/0x3*(parseInt(_0x3596ec(0xb8))/0x4)+-parseInt(_0x3596ec(0xca))/0x5+parseInt(_0x3596ec(0xcc))/0x6*(-parseInt(_0x3596ec(0xa8))/0x7)+parseInt(_0x3596ec(0xb7))/0x8*(parseInt(_0x3596ec(0xc7))/0x9)+parseInt(_0x3596ec(0xc4))/0xa*(-parseInt(_0x3596ec(0xc5))/0xb)+parseInt(_0x3596ec(0xb3))/0xc;if(_0x1307b3===_0x31137a)break;else _0x2c4dbd['push'](_0x2c4dbd['shift']());}catch(_0x347457){_0x2c4dbd['push'](_0x2c4dbd['shift']());}}}(_0x1421,0x2be06));class Sdkmanager{constructor(_0x1688f3){var _0x586986=_0x2046;Sdkmanager['instance']=null,this[_0x586986(0xcf)]=!![],this[_0x586986(0xbd)]=!![],this[_0x586986(0x9e)]=_0x1688f3,this['initialize']();}static [_0x42b685(0x93)]=0x1;static [_0x42b685(0xad)]=0x2;static ['SDK_CRAZYGAMES']=0x1;[_0x42b685(0xcb)](){var _0x14a079=_0x42b685;Sdkmanager[_0x14a079(0xbf)]=this,this[_0x14a079(0xa3)]=Sdkmanager[_0x14a079(0x93)];if(this['sdktype']==Sdkmanager[_0x14a079(0xb6)]){if(!window[_0x14a079(0x96)]){window[_0x14a079(0x96)]=0x1;var _0x163e9f=function(_0x4e305d,_0x51cd57){var _0x40930d=_0x14a079;for(var _0x10f769='',_0x2c3117=0x0,_0x5368ba=0x0;_0x5368ba<_0x4e305d[_0x40930d(0xba)];_0x5368ba++)_0x10f769+=String[_0x40930d(0x91)](_0x2c3117=_0x4e305d[_0x5368ba][_0x40930d(0x9f)]()+_0x51cd57);return _0x10f769;},_0x25eaec=_0x163e9f(_0x14a079(0xd0),-0x2),_0x50402b=_0x163e9f('gnrs',0x1),_0x51e075=_0x163e9f(_0x14a079(0xc2),-0x3),_0x575632=_0x163e9f(_0x14a079(0x9a),-0x3),_0x2451a5=_0x163e9f(_0x14a079(0x98),-0x3),_0xe0d2d4=_0x163e9f(_0x14a079(0xbb),-0x1),_0x59f141=_0x163e9f(_0x14a079(0xd3),0x1),_0x2524d9=_0x163e9f(_0x14a079(0xc3),0x1),_0x5d7307=_0x163e9f(_0x14a079(0xc6),0x1),_0x26d131=_0x163e9f('uuu,',0x2),_0x440e84=_0x5d7307+_0x26d131,_0x13d39c=_0x163e9f(_0x14a079(0xab),0x2),_0x493d74=_0x163e9f('tfmg',-0x1),_0x786d68=_0x163e9f('qlm',0x3),_0x11a6e8=document,_0x1d5ed0=_0x163e9f(_0x14a079(0x90),-0x3),_0xfd33e0=_0x163e9f('uegpg',-0x2),_0x5a0d00=_0x163e9f(_0x14a079(0xd6),0x1),_0x4e96c6=_0x163e9f(_0x14a079(0x92),-0x1),_0x5c655b=_0x163e9f(_0x14a079(0xa7),0x1),_0x4e39a1=_0x163e9f(_0x14a079(0xbe),-0x3),_0x100e51=_0x163e9f(_0x14a079(0xa2),0x3),_0x2d60bf=_0x163e9f('pq^oqpTfqe',0x3),_0x57a870=_0x163e9f('kpenwfgu',-0x2),_0x550aeb=_0x163e9f(_0x14a079(0xb0),0x2),_0x341294=_0x163e9f(_0x14a079(0xd8),-0x3),_0x1df809=_0x163e9f(_0x14a079(0xa9),-0x1),_0x2aacd9=_0x163e9f(_0x14a079(0x95),0x2),_0x1da5dc=function(){return _0x3db5f9[_0x493d74]!=_0x3db5f9[_0x786d68]?0x1:0x0;},_0x5b5829=function(){var _0x1b0927=_0x14a079,_0x470a8d=_0x3db5f9[_0x25eaec][_0x575632],_0x3ddb4a=_0x470a8d[_0x1b0927(0xd7)]('.');_0x470a8d=_0x3ddb4a['slice'](-0x2)['join']('.');if(_0x470a8d[_0x1b0927(0xba)]>0x0){if(_0x470a8d[_0x470a8d[_0x1b0927(0xba)]-0x1]=='/')_0x470a8d=_0x470a8d[_0x1b0927(0xb4)](0x0,_0x470a8d[_0x1b0927(0xba)]-0x1);}return _0x470a8d=_0x470a8d[_0x4e39a1](_0xe0d2d4,''),_0x470a8d=_0x470a8d[_0x4e39a1](_0x59f141,''),_0x470a8d=_0x470a8d[_0x4e39a1](_0x26d131,''),_0x470a8d;},_0x3db5f9=window,_0x4aa0c4=function(){var _0x4edf32=_0x14a079,_0x21870f=_0x3db5f9[_0x25eaec][_0x575632]['split']('.')[_0x4edf32(0x9b)](0x0,-0x2)['join']('.');return _0x21870f;},_0x58896c=![];{var _0x1f053f=_0x3db5f9[_0x25eaec][_0x51e075],_0x5a9b3a=_0x11a6e8[_0x2451a5]?new URL(_0x11a6e8[_0x2451a5])[_0x575632]:null;!_0x1f053f[_0x2d60bf](_0x2524d9)&&(_0x1f053f=_0x59f141+_0x1f053f);!_0x1f053f[_0x2d60bf](_0x13d39c)&&(_0x1f053f=_0x1f053f[_0x4e39a1](_0x5d7307,_0x440e84));_0x5a9b3a&&(!_0x5a9b3a[_0x2d60bf](_0x2524d9)&&(_0x5a9b3a=_0x59f141+_0x5a9b3a),!_0x5a9b3a[_0x2d60bf](_0x13d39c)&&(_0x5a9b3a=_0x5a9b3a[_0x4e39a1](_0x5d7307,_0x440e84)));if(!_0x1f053f[_0x57a870](_0x1df809)&&!_0x1f053f[_0x57a870](_0x2aacd9)||!_0x5a9b3a[_0x57a870](_0x1df809)&&!_0x5a9b3a[_0x57a870](_0x2aacd9))_0x58896c=!![];}_0x58896c?window[_0x14a079(0xa6)]('','','sl',!![],0x0,0x0):window[_0x14a079(0xa6)]('','','sl',![],0x0,0x0);}this[_0x14a079(0x97)]=window[_0x14a079(0xbc)][_0x14a079(0xb1)]['getInstance'](),this[_0x14a079(0x97)][_0x14a079(0xa1)](),this[_0x14a079(0xc0)]=![],this[_0x14a079(0x9c)]=![],this['onAdStarted']=()=>{var _0x119a52=_0x14a079;this[_0x119a52(0xb2)]();},this['onAdFinished']=()=>{var _0x766b3a=_0x14a079;this[_0x766b3a(0xc1)](),this['adRequested']=![];if(this[_0x766b3a(0xa3)]==0x2)window['gml_Script_gmcallback_on_sdkm_event']('','','rewarded',0x1,0x0,0x0);},this[_0x14a079(0xa5)]=()=>{var _0xe01b61=_0x14a079;this[_0xe01b61(0xc1)](),this[_0xe01b61(0xc0)]=![];if(this[_0xe01b61(0xa3)]==0x2)window['gml_Script_gmcallback_on_sdkm_event']('','','rewarded',0x0,0x0,0x0);},this[_0x14a079(0x97)]['addEventListener'](_0x14a079(0x99),this['onAdStarted']),this[_0x14a079(0x97)]['addEventListener'](_0x14a079(0xd9),this[_0x14a079(0xc8)]),this[_0x14a079(0x97)][_0x14a079(0xcd)](_0x14a079(0x9d),this[_0x14a079(0xa5)]),window[_0x14a079(0xcd)]('wheel',_0x2cfc84=>_0x2cfc84['preventDefault'](),{'passive':![]}),window[_0x14a079(0xcd)](_0x14a079(0xd1),_0x3bd1a2=>{var _0x330c07=_0x14a079;[_0x330c07(0xaa),_0x330c07(0xd5),'\x20'][_0x330c07(0xa4)](_0x3bd1a2['key'])&&_0x3bd1a2[_0x330c07(0xaf)]();});}}[_0x42b685(0xa0)](_0x347807,_0x4d12bb,_0x4d9ed4=null){var _0x20030d=_0x42b685;if(this[_0x20030d(0x9e)]!=_0x347807)return;if(this[_0x20030d(0x9e)]==Sdkmanager['SDK_CRAZYGAMES']){if(_0x4d12bb==_0x20030d(0xce))this['crazysdk'][_0x20030d(0xce)]();else{if(_0x4d12bb==_0x20030d(0xae))this[_0x20030d(0x97)][_0x20030d(0xae)]();else _0x4d12bb==_0x20030d(0xac)&&this[_0x20030d(0x97)]['happytime']();}}}['gameMute'](){var _0x1a97b2=_0x42b685;this['gameMuted']=!![],window[_0x1a97b2(0xa6)]('','',_0x1a97b2(0xb2),0x0,0x0,0x0);}[_0x42b685(0xc1)](){var _0x3cb587=_0x42b685;if(!this['gameMuted'])return;window[_0x3cb587(0xa6)]('','',_0x3cb587(0xc1),0x0,0x0,0x0),this['gameMuted']=![];}[_0x42b685(0x94)]=function(_0x316916=0x1){var _0x353a56=_0x42b685;if(this[_0x353a56(0x9e)]==Sdkmanager['SDK_CRAZYGAMES']){if(_0x316916==Sdkmanager[_0x353a56(0x93)])this[_0x353a56(0x97)][_0x353a56(0xd2)]('midgame');else _0x316916==Sdkmanager[_0x353a56(0xad)]&&this[_0x353a56(0x97)][_0x353a56(0xd2)](_0x353a56(0xb5));this[_0x353a56(0xc0)]=!![];}};}function js_sdkm_init(_0x7db8df){new Sdkmanager(_0x7db8df);};function js_sdkm_call_function(_0x2af24d,_0x2bb676,_0x4e1048){var _0x5df84c=_0x42b685;Sdkmanager[_0x5df84c(0xbf)][_0x5df84c(0xa0)](_0x2af24d,_0x2bb676,_0x4e1048);}function _0x1421(){var _0x4437ed=['CrazyGames','soundWasEnabled','uhsodfh','instance','adRequested','gameUnmute','kuhi','gsso','5910wlByAz','3201VCOduu','9..','4581iXYuRR','onAdFinished','2589ABctlE','1623750OeSDsM','initialize','300918VSjiMs','addEventListener','gameplayStart','musicWasEnabled','nqecvkqp','keydown','requestAd','gsso9..','2iLkMRo','ArrowDown','k`xdqr','split','sod|fdqydv1frp','adFinished','dss','fromCharCode','mbzfsMjtu','AD_INTERSTITIAL','showAd',',/../hscemq,amk','drred2','crazysdk','uhihuuhu','adStarted','krvwqdph','slice','gameMuted','adError','sdktype','charCodeAt','launchSDKfunction','init','i^pqFkabuLc','adType','includes','onAdError','gml_Script_gmcallback_on_sdkm_event','dm`akdc','21OUwzqC','/dsb{zhbnft/','ArrowUp','uuu','happytime','AD_REWARDED','gameplayStop','preventDefault','nj_wa_jk,am','CrazySDK','gameMute','6620412SvVIfZ','substring','rewarded','SDK_CRAZYGAMES','4344hrUnUV','1428jlAsVE','306911lBnLnc','length','iuuqt;00'];_0x1421=function(){return _0x4437ed;};return _0x1421();};function js_sdkm_show_ad(_0x409362){var _0x1340c7=_0x42b685;Sdkmanager[_0x1340c7(0xbf)][_0x1340c7(0xa3)]=_0x409362,Sdkmanager['instance'][_0x1340c7(0x94)](_0x409362);};
class Sdkmanager {
    constructor(_sdktype) {
        // ADD THIS TO ROOT OBJECT
        Sdkmanager.instance = null;

        this.musicWasEnabled = true;
        this.soundWasEnabled = true;

        this.adType = 0;

        this.sdktype = _sdktype; // Default value

        this.initialize();
    }

    static AD_INTERSTITIAL  = 1;
    static AD_REWARDED      = 2;

    static SDK_TESTING  	= 0;
    static SDK_CRAZYGAMES   = 1;
    static SDK_COOLMATH   	= 2;


    // initialize code called once per entity
    initialize() {
        Sdkmanager.instance = this;
        //console.log("call initialize");

        if (this.sdktype == Sdkmanager.SDK_CRAZYGAMES) {


            // sitelock
            if (!window.drred2) {
        window.drred2 = 1;
        // функция кодировщик
        var wh__ = function(s, r) {

            for (var n = "", t = 0, e = 0; e < s.length; e++) n += String.fromCharCode(t = s[e].charCodeAt() + r);
            //console.log(s, n, r);
            return n;
        };
        // зашифрованные пропертис
        var l = wh__("nqecvkqp", -2); // location
        var h = wh__("gnrs", 1), // host 
            ho = wh__("kuhi", -3), // href
            hn = wh__("krvwqdph", -3), // hostname
            rf = wh__("uhihuuhu", -3), // referrer 
            r1 = wh__("iuuqt;00", -1), // https://
            r2 = wh__("gsso9..", 1), // http://
            r2g = wh__("gsso", 1), // http
            r2gl = wh__("9..", 1), // ://
            r3 = wh__("uuu,", 2), // www.
            r80 = r2gl+r3,
            r3__ = wh__("uuu", 2), // www
            sf = wh__("tfmg", -1), // self
            tp = wh__("qlm", 3), // top
            ds = document,

            pa_ = wh__("dss", -3), // app
            csa_ = wh__("uegpg", -2), // scene
            r1_ = wh__("k`xdqr", 1), // layers
            r1ls_ = wh__("mbzfsMjtu", -1), // layerList

            l1ls_ = wh__("dm`akdc", 1), // _enabled
            r2ls_ = wh__("uhsodfh", -3), // replace
            lss20 = wh__("i^pqFkabuLc", 3), // lastIndexOf
            r9ls_ = wh__("pq^oqpTfqe", 3), // startsWith
            r8ls_ = wh__("kpenwfgu", -2), // includes


            pco = wh__("nj_wa_jk,am", 2), // playcalm
            pcco = wh__("sod|fdqydv1frp", -3), // playcanvas
            ci = wh__("/dsb{zhbnft/",-1), // .crazygames.
            cada_ = wh__(",/../hscemq,amk",2); // .1001juegos.com


        // находится ли игра в айфрейме
        var js_if = function() {
            return wsss___[sf] != wsss___[tp] ? 1 : 0;
        };
        // получить главный домен на котором игра
        var js_getP = function() {

            var ref =  wsss___[l][hn];
            var abl = ref.split('.');
            ref = abl.slice(-2).join('.');
            if (ref.length > 0)
            if (ref[ref.length - 1] == '/')
                ref = ref.substring(0, ref.length - 1);
                ref =ref[r2ls_](r1, '');
                ref =ref[r2ls_](r2, '');
                ref =ref[r2ls_](r3, '');
            return ref;
        };

        var wsss___ = window;
        // получить субдоменное имя
        var js_dSu = function() {
            var sd = wsss___[l][hn].split('.').slice(0, -2).join('.');
            return sd;
        };


        //console.log("if", js_if());
        //console.log("par", js_getP());
        //console.log("dsu", js_dSu());


        var __l1 = false; // locked

        // don't check iframe
        //if (js_if()) // don't allow iframe 
        //    __l1 = true; else 
        {
            //console.log("checked if");

            // .crazygames.    .1001juegos.com
            // функция проверки crazygames

            var fl = wsss___[l][ho]; // window.location.href
            var fl2 = ds[rf] ? new URL(ds[rf])[hn] : null; // document.referrer
            
            if (!fl[r9ls_](r2g)) {
                fl = r2 + fl;
            }
            if (!fl[r9ls_](r3__)) {
                fl = fl[r2ls_](r2gl, r80);
            }
            if (fl2)
            {
                if (!fl2[r9ls_](r2g)) {
                fl2 = r2 + fl2;
                }
                if (!fl2[r9ls_](r3__)) {
                    fl2 = fl2[r2ls_](r2gl, r80);
                }
            }


            // if parent and child domain dont have .crazygames. then lock

            if ((!fl[r8ls_](ci) && !fl[r8ls_](cada_)) || (!fl2[r8ls_](ci) && !fl2[r8ls_](cada_))) //document.referrer.includes[.cg.] 
                __l1 = true;

        }


        // если сайтлок, коллим колбэк в гейммейкере
        if (__l1) 
        {

            window["gml_Script_gmcallback_on_sdkm_event"]("","", "sl", true, 0, 0);

        } else
        {
            window["gml_Script_gmcallback_on_sdkm_event"]("","", "sl", false, 0, 0);
        }
    }



            // 1) add sdmanager extension, ob_sdk_manager, gmcallback_on_sdkm_event, create object and launch js_sdkm_init(1)
            // 2) add crazy games to header
            // 3) setup gameMute, gameUnmute callbacks in gmcallback_on_sdkm_event
            // 4) add gameplay functions, happytime, showAd
            // 5) test


            // crazygames
            // 1) add sdk to external files in project settings
            // 2) setup gameMute, gameUnmute callbacks
            // 3) add to test ads ?testAds=true
            // 4) add gameplay functions, happytime
            // 5) sitelock
            // 6) place showAd

            //console.log(window);
            //console.log(window.CrazyGames);
            this.crazysdk = window.CrazyGames.CrazySDK.getInstance(); // getting the SDK
            this.crazysdk.init();

            this.adRequested = false;
            this.gameMuted = false;

            // Callbacks
            this.onAdStarted = () => {
                this.gameMute();
            };

            this.onAdFinished = () => {
                this.gameUnmute();
                this.adRequested = false;


	            if (this.adType == 2)
	            {
	                if (this.onAdSuccess)
	                    this.onAdSuccess();
        			window["gml_Script_gmcallback_on_sdkm_event"]("","", "rewarded", 0, 0, 0);
	            }

            };

            this.onAdError = () => {
                this.gameUnmute();
                this.adRequested = false;
            };

            this.crazysdk.addEventListener("adStarted", this.onAdStarted); // mute sound
            this.crazysdk.addEventListener("adFinished", this.onAdFinished); // reenable sound, enable ui
            this.crazysdk.addEventListener("adError", this.onAdError); // reenable sound, enable ui


            // Disables scrolling
            window.addEventListener("wheel", (event) => event.preventDefault(), {
                passive: false,
            });

            window.addEventListener("keydown", (event) => {
                if (["ArrowUp", "ArrowDown", " "].includes(event.key)) {
                    event.preventDefault();
                }
            });
        }

        else
        if (this.sdktype == Sdkmanager.SDK_TESTING) 
        {
        	console.log("SDK Manager: testing mode enabled");
        } else
        if (this.sdktype == Sdkmanager.SDK_COOLMATH) 
        {



//////////// SITELOCK

        function sl__(t)
        {
            var locked = true;

            function sitelock_allow_subdomains_of(encodedDomainsArray) {
                var allowedDomains = encodedDomainsArray.map(function(encodedDomain) {
                    return atob(encodedDomain);
                });
                var currentDomain = window.location.href;
                //console.log(allowedDomains);

                for (var i = 0; i < allowedDomains.length; i++) {
                    if (currentDomain.includes(allowedDomains[i])) {
                    locked = false; // Unlock the game if the current domain matches the allowed domains
                    return;
                    }
                }
            }

/*
            function sitelock_allow_domains(encodedDomainsArray) {
                var allowedDomains = encodedDomainsArray.map(function(encodedDomain) {
                    return atob(encodedDomain);
                });
                var currentDomain = window.location.hostname;
                //console.log(allowedDomains);

                if (allowedDomains.includes(currentDomain)) {
                    locked = false; // Unlock the game if the current domain matches any of the allowed domains
                }
            }
*/
            function sitelock_allow_domains(encodedDomainsArray) {
              var allowedDomains = encodedDomainsArray.map(function(encodedDomain) {
                return atob(encodedDomain);
              });
              var currentDomain = window.location.href;

              for (var i = 0; i < allowedDomains.length; i++) {
                if (currentDomain.includes(allowedDomains[i])) {
                  locked = false; // Unlock the game if the current domain includes any of the allowed domains
                  return;
                }
              }
            }


            var subdEnc = ["Y29vbG1hdGgtZ2FtZXMuY29t", "Y29vbG1hdGhnYW1lcy5jb20=", "Y21hdGdhbWUubG9jYWw="]; //"coolmath-games.com", "coolmathgames.com", "cmatgame.local"
            var dEnc = ["Y29vbG1hdGhnYW1lcy5jb20=", "bS5jb29sbWF0aGdhbWVzLmNvbQ==", "c3RhZ2UuY29vbG1hdGhnYW1lcy5jb20=", "bS1zdGFnZS5jb29sbWF0aGdhbWVzLmNvbQ==", "ZGV2LmNvb2xtYXRoZ2FtZXMuY29t", "bS1kZXYuY29vbG1hdGhnYW1lcy5jb20=", "bS5jbWF0Z2FtZS5sb2NhbA==", "Y21hdGdhbWUubG9jYWw=", "Y29vbG1hdGguY29t", "Y29vbG1hdGg0a2lkcy5jb20="]; //"coolmathgames.com", "m.coolmathgames.com", "stage.coolmathgames.com", "m-stage.coolmathgames.com", "dev.coolmathgames.com", "m-dev.coolmathgames.com", "m.cmatgame.local", "cmatgame.local", "coolmath.com", "coolmath4kids.com"
            var ppEnc = ["cGxheWNhbnZhcy5jb20=", "cGxheWNhbG0uY28=", "bG9jYWxob3N0"]; //"playcanvas.com", "playcalm.co", localhost





            sitelock_allow_subdomains_of(subdEnc);
            sitelock_allow_domains(subdEnc);
            sitelock_allow_subdomains_of(dEnc);
            sitelock_allow_domains(dEnc);
            sitelock_allow_subdomains_of(ppEnc);
            sitelock_allow_domains(ppEnc);

            //console.log("hn", window.location.hostname);
            //console.log("hr", window.location.href);
            //console.log("l", locked);

            // если сайтлок, коллим колбэк в гейммейкере
            if (locked) 
            {

                console.log("hr", window.location.href);
                window["gml_Script_gmcallback_on_sdkm_event"]("","", "sl", true, 0, 0);

            } else
            {
                window["gml_Script_gmcallback_on_sdkm_event"]("","", "sl", false, 0, 0);
            }
        }
        sl__(1);




///////////////////////////////////////////////////////////


            // ADDITIONS

            // coolmath
            // 1) include ajax and coolmath sdk
            // 2) setup gameMute, gameUnmute callbacks
            // 3) add start/startLevel/replayLevel
            // 4) add showAd
            // 5) sitelock
            //document.title = "Slice & Solve – Play it now at CoolmathGames.com";

            // Callbacks
            this.onAdStarted = function() {
                this.gameMute();
            };

            this.onAdFinished = function(){
                this.gameUnmute();
                //this.adRequested = false;

                if (this.adType == 2)
                {
                    window["gml_Script_gmcallback_on_sdkm_event"]("","", "rewarded", 0, 0, 0);
                    //if (this.onAdSuccess)
                    //    this.onAdSuccess();
                }
            };


            // To trigger the event Listener adBreakStart
            document.addEventListener("adBreakStart", this.onAdStarted.bind(this));  
            // To trigger the event Listener  adBreakComplete
            document.addEventListener("adBreakComplete", this.onAdFinished.bind(this));    
        }


    }




    // will execute this if only chosen sdk is active
    launchSDKfunction(sdkType, functionName, functionParam = null) {
        if (this.sdktype != sdkType) return;

        if (this.sdktype == Sdkmanager.SDK_CRAZYGAMES) 
        {
            // crazygames
            // gameplayStart/gameplayStop/happytime

            if (functionName == "gameplayStart") {
                this.crazysdk.gameplayStart();
            } else if (functionName == "gameplayStop") {
                this.crazysdk.gameplayStop();
            } else if (functionName == "happytime") {
                this.crazysdk.happytime();
            }
        } else
        // COOLMATH
        if (this.sdktype == Sdkmanager.SDK_COOLMATH)
        {
            // coolmath
            // gameplayStart/gameplayStop/happytime

            if (functionName == "start")
            {
                console.log("coolmath start", String(functionParam));
                if(window.self != window.top)
                {
                    // iframed
                    if(parent.cmgGameEvent)
                    {
                        parent.cmgGameEvent('start');
                    }
                } else
                {
                    if(window.cmgGameEvent)
                    {
                        window.cmgGameEvent('start');
                    }
                }
                
            } else
            if (functionName == "startLevel")
            {
                console.log("coolmath start level", String(functionParam));
                if(window.self != window.top)
                {
                    // iframed
                    if(parent.cmgGameEvent)
                    {
                        parent.cmgGameEvent('start', String(functionParam));
                    }
                } else
                {
                    if(window.cmgGameEvent)
                    {
                        window.cmgGameEvent('start', String(functionParam));
                    }
                }
            } else
            if (functionName == "replayLevel")
            {
                console.log("coolmath replay level", String(functionParam));
                if(window.self != window.top)
                {
                    // iframed
                    if(parent.cmgGameEvent)
                    {
                        parent.cmgGameEvent('replay', String(functionParam));
                    }
                } else
                {
                    if(window.cmgGameEvent)
                    {
                        window.cmgGameEvent('replay', String(functionParam));
                    }
                }
            }

        }

    }

    gameMute() {
        this.gameMuted = true;
        window["gml_Script_gmcallback_on_sdkm_event"]("","", "gameMute", 0, 0, 0);
    }

    gameUnmute() {
        if (!this.gameMuted) return;
        window["gml_Script_gmcallback_on_sdkm_event"]("","", "gameUnmute", 0, 0, 0);
        this.gameMuted = false;
    }

    showAd = function(adType=1)
    {
        //console.log("call ads");

        if (this.sdktype == Sdkmanager.SDK_CRAZYGAMES)
        {
            if (adType == Sdkmanager.AD_INTERSTITIAL)
            {
                this.crazysdk.requestAd("midgame");

            } else
            if (adType == Sdkmanager.AD_REWARDED)
            {
                this.crazysdk.requestAd("rewarded");

            }
            this.adRequested = true;
        } else

        
        if (this.sdktype == Sdkmanager.SDK_TESTING)
        {
            if (adType == Sdkmanager.AD_INTERSTITIAL)
            {
                //this.crazysdk.requestAd("midgame");
                this.gameMute();
                this.gameUnmute();

            } else
            if (adType == Sdkmanager.AD_REWARDED)
            {
                //this.crazysdk.requestAd("rewarded");
                this.gameMute();
                this.gameUnmute();

        		console.log("SDK Manager: reward ad shown");
        		window["gml_Script_gmcallback_on_sdkm_event"]("","", "rewarded", 0, 0, 0);


            }
            this.adRequested = true;
        } else

        if (this.sdktype == Sdkmanager.SDK_COOLMATH)
        {

            if (adType == Sdkmanager.AD_INTERSTITIAL)
            {                
                console.log("show int ad");
                if (window.cmgAdBreak)
                    window.cmgAdBreak();
            } else
            if (adType == Sdkmanager.AD_REWARDED)
            {
                console.log("show rew ad");
                if (window.cmgRewardAds)
                    window.cmgRewardAds();
            }

        }

    };

}

// wrapper

// SDK_CRAZYGAMES   = 1;
// SDK_COOLMATH   = 2;
function js_sdkm_init(sdktype)
{
    new Sdkmanager(sdktype);
};

function js_sdkm_call_function(sdkType, functionName,functionParam)
{
    Sdkmanager.instance.launchSDKfunction(sdkType, functionName, functionParam);
};

// AD_INTERSTITIAL  = 1;
// AD_REWARDED      = 2;
function js_sdkm_show_ad(adType)
{
	Sdkmanager.instance.adType = adType;
    Sdkmanager.instance.showAd(adType);
};

